Iconset: File Extension Names Vol 8 (https://www.iconfinder.com/iconsets/file-extension-names-vol-8)
Author: Simran Singh (https://www.iconfinder.com/SimranSingh)
License: Free for commercial use ()
Download date: 2023-10-11